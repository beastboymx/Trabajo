package solicitud;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import javax.swing.text.AbstractDocument;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class turno1 extends javax.swing.JFrame {
// --- Constantes ---
    private static final String RUTA_ARCHIVO = "O:\\Department\\SerialesEyD\\solicitudesT1.txt";
    private static final String ZONA_HORARIA_MEXICO = "GMT-6";

    // Índices de columnas para fácil mantenimiento
    private static final int COL_HORA = 5;
    private static final int COL_FECHA = 6;
    private static final int COL_ESTATUS = 7;

    // --- Variables de Clase ---
    private DefaultTableModel tableModel;
    private String rutaArchivo;
    private Timer timer; // Para el reloj
    // private Timer timerUpdater; // <-- ELIMINADO: Ya no se usa el timer para actualizar
    
    // Formatters (se inicializan una vez)
    private TimeZone zonaMexico;
    private SimpleDateFormat FORMATO_HORA;
    private SimpleDateFormat FORMATO_FECHA_RELOJ;
    private SimpleDateFormat FORMATO_FECHA_ARCHIVO;
    private SimpleDateFormat SDF_PARSE_DATETIME;

    public turno1() {
         initComponents();
        
         inicializarVariables();
         configurarVentana();
         configurarCamposTexto(); 
         configurarTabla();
         iniciarTimers(); // <-- Este método ahora inicia el WatchService
         if (lblVersion != null) { // Asume que tienes un JLabel llamado lblVersion
         lblVersion.setText(VersionApp.getTextoVersion());
        }
        
         // Carga inicial de datos
         cargarArchivoEnJTSolicitudes();
    }
    
    @Override
    public Image getIconImage() {
        Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/b.png"));
        return retValue;
    }
    
private void inicializarVariables() {
         tableModel = (DefaultTableModel) jtRegistros.getModel();
         rutaArchivo = RUTA_ARCHIVO; // Asigna desde la constante

         // Configura la zona horaria y los formatos de fecha/hora una sola vez
         zonaMexico = TimeZone.getTimeZone(ZONA_HORARIA_MEXICO);
        
         FORMATO_HORA = new SimpleDateFormat("hh:mm:ss a");
         FORMATO_HORA.setTimeZone(zonaMexico);

         FORMATO_FECHA_RELOJ = new SimpleDateFormat("dd-MM-yyyy");
         FORMATO_FECHA_RELOJ.setTimeZone(zonaMexico);
        
         FORMATO_FECHA_ARCHIVO = new SimpleDateFormat("dd/MM/yyyy");
         FORMATO_FECHA_ARCHIVO.setTimeZone(zonaMexico);
        
         SDF_PARSE_DATETIME = new SimpleDateFormat("hh:mm:ss a dd/MM/yyyy");
         SDF_PARSE_DATETIME.setTimeZone(zonaMexico);
    }

     /**
      * Configura las propiedades de la ventana (JFrame).
      */
     private void configurarVentana() {
         actualizarFechaYHora(); // Primera actualización
         Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
         setLocationRelativeTo(null);
         setVisible(true);
         this.setResizable(false);
         setIconImage(getIconImage());
     }
    
     private void configurarCamposTexto() {
         DocumentFilter upperCaseFilter = new UpperCaseDocumentFilter();

         ((AbstractDocument) jtWO.getDocument()).setDocumentFilter(upperCaseFilter);
         ((AbstractDocument) jtProyecto.getDocument()).setDocumentFilter(upperCaseFilter);
     }
    
     private class UpperCaseDocumentFilter extends DocumentFilter {

         @Override
         public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
                 throws BadLocationException {
            
             if (string != null) {
                 string = string.toUpperCase(); // Convierte el string a mayúsculas
             }
             super.insertString(fb, offset, string, attr);
         }

         @Override
         public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                 throws BadLocationException {
            
             if (text != null) {
                 text = text.toUpperCase(); // Convierte el texto de reemplazo a mayúsculas
             }
             super.replace(fb, offset, length, text, attrs);
         }
     }


private void configurarTabla() {
         // --- Renderers (Apariencia) ---

         // Centrar los títulos de las columnas
         DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
         headerRenderer.setHorizontalAlignment(JLabel.CENTER);

         // Centrar el contenido de las celdas
         DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
         centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
         // Color de texto
         DefaultTableCellRenderer textRenderer = new DefaultTableCellRenderer();
         textRenderer.setForeground(Color.BLACK);
         jtRegistros.setDefaultRenderer(Object.class, textRenderer);

         for (int i = 0; i < jtRegistros.getColumnModel().getColumnCount(); i++) {
             jtRegistros.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
             jtRegistros.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
         }

         // Renderer especial para la columna Estatus (con colores Y CENTRADO)
         jtRegistros.getColumnModel().getColumn(COL_ESTATUS).setCellRenderer(new DefaultTableCellRenderer() {
             @Override
             public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                 Component cellComponent = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                 // Esta línea centra el texto en esta columna específica
                 setHorizontalAlignment(JLabel.CENTER);

                 String estatus = (String) value;
                
                 if (isSelected) {
                     // Mantener el color de selección si la celda está seleccionada
                     cellComponent.setBackground(table.getSelectionBackground());
                     cellComponent.setForeground(table.getSelectionForeground());
                 } else if (estatus != null) {
                     // Aplicar colores según el estatus
                     switch (estatus) {
                         case "Abierto":
                             cellComponent.setBackground(Color.YELLOW);
                             cellComponent.setForeground(Color.BLACK);
                             break;
                         case "Cancelado":
                             cellComponent.setBackground(Color.RED);
                             cellComponent.setForeground(Color.WHITE);
                             break;
                         case "Cerrado":
                             cellComponent.setBackground(Color.GREEN);
                             cellComponent.setForeground(Color.BLACK);
                             break;
                         default:
                             cellComponent.setBackground(table.getBackground());
                             cellComponent.setForeground(table.getForeground());
                             break;
                     }
                 } else {
                      cellComponent.setBackground(table.getBackground());
                      cellComponent.setForeground(table.getForeground());
                 }

                 return cellComponent;
             }
         });

         // --- Configuración de Columnas y Grid ---
         jtRegistros.getColumnModel().getColumn(0).setPreferredWidth(50); //Requiere
         jtRegistros.getColumnModel().getColumn(1).setPreferredWidth(30);//WO
         jtRegistros.getColumnModel().getColumn(2).setPreferredWidth(100);//Panel1
         jtRegistros.getColumnModel().getColumn(3).setPreferredWidth(100);//Panel2
         jtRegistros.getColumnModel().getColumn(4).setPreferredWidth(30);//Proyecto
         jtRegistros.getColumnModel().getColumn(5).setPreferredWidth(30);//Hora
         jtRegistros.getColumnModel().getColumn(6).setPreferredWidth(30);//Fecha
         jtRegistros.getColumnModel().getColumn(7).setPreferredWidth(30);//Status
         jtRegistros.getColumnModel().getColumn(8).setPreferredWidth(250);//Comentario
         jtRegistros.getColumnModel().getColumn(9).setPreferredWidth(50);//Atendió

         jtRegistros.setShowGrid(true);
         jtRegistros.setGridColor(java.awt.Color.BLACK);
         jtRegistros.setShowHorizontalLines(true);
         jtRegistros.setShowVerticalLines(true);

         // --- Sorter (Ordenamiento) ---
         TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(tableModel);
         jtRegistros.setRowSorter(sorter);

         JTableHeader header = jtRegistros.getTableHeader();
         header.addMouseListener(new MouseAdapter() {
             @Override
             public void mouseClicked(MouseEvent e) {
                 int columnIndex = header.columnAtPoint(e.getPoint());
                 if (columnIndex != -1) {
                     sorter.toggleSortOrder(columnIndex);
                 }
             }
         });
    }

    /**
     * Inicializa el reloj de la UI y el monitoreo de archivo en tiempo real.
     */
    private void iniciarTimers() {
        // Timer para el reloj (1 segundo)
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarFechaYHora();
            }
        });
        timer.start();

        // --- CAMBIO ---
        // Se elimina el timerUpdater y se inicia el monitoreo de archivo
        iniciarMonitoreoArchivo();
    }

    // --- MÉTODO NUEVO ---
    /**
     * Inicia un servicio en un hilo separado para monitorear cambios
     * en el archivo de solicitudes (usando WatchService) y actualiza la
     * tabla en tiempo real.
     */
private void iniciarMonitoreoArchivo() {
    Thread hiloMonitoreo = new Thread(() -> {
        try {
            Path directorio = Paths.get("O:\\Department\\SerialesEyD\\");
            WatchService watchService = FileSystems.getDefault().newWatchService();
            directorio.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY, StandardWatchEventKinds.ENTRY_CREATE);

            while (true) {
                WatchKey key = watchService.take();
                for (WatchEvent<?> event : key.pollEvents()) {
                    String nombreArchivo = event.context().toString();

                    // 1. Si cambia el archivo de solicitudes, actualiza la tabla (tu código actual)
                    if (nombreArchivo.equals("solicitudesT1.txt")) {
                        SwingUtilities.invokeLater(() -> cargarArchivoEnJTSolicitudes());
                    }
                    
                    // 2. NUEVO: Si cambia o se crea el archivo de avisos
                    if (nombreArchivo.equals("avisos.txt")) {
                        verificarAvisoExtra();
                    }
                }
                key.reset();
            }
        } catch (Exception e) { e.printStackTrace(); }
    });
    hiloMonitoreo.setDaemon(true);
    hiloMonitoreo.start();
}

// Método para leer el archivo de avisos y mostrar el JOptionPane
private void verificarAvisoExtra() {
    File archivoAviso = new File("O:\\Department\\SerialesEyD\\avisos.txt");
    if (!archivoAviso.exists()) return;

    try (BufferedReader reader = new BufferedReader(new FileReader(archivoAviso))) {
        String contenido = reader.readLine();
        if ("MOSTRAR_ALERTA".equals(contenido)) {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, 
                    "No es necesario llamar al Soporte para dar de alta los seriales.\n" +
                    "Se darán de alta conforme se tenga disponibilidad de los técnicos de procesos. \n \n" +
                     "Ingeniera de Procesos", 
                    "AVISO DE SOPORTE", 
                    JOptionPane.WARNING_MESSAGE);
            });
            
            // IMPORTANTE: Después de mostrarlo, borramos el contenido para que no salga otra vez
            limpiarArchivoAviso(archivoAviso);
        }
    } catch (IOException e) { /* Manejar error silenciosamente */ }
}

private void limpiarArchivoAviso(File f) {
    try (FileWriter fw = new FileWriter(f)) {
        fw.write(""); // Lo deja vacío
    } catch (IOException e) { e.printStackTrace(); }
}
    // --- FIN MÉTODO NUEVO ---

private void cargarArchivoEnJTSolicitudes() {
         try (BufferedReader reader = new BufferedReader(new FileReader(this.rutaArchivo))) {
             String linea;
             List<String[]> data = new ArrayList<>(); // Lista para almacenar los datos

             // Leer todas las líneas y almacenarlas en la lista
             while ((linea = reader.readLine()) != null) {
                 if (linea.trim().isEmpty()) continue; // Ignorar líneas vacías
                 
                 String[] datos = linea.split(";");
                 data.add(datos);
             }

             // Ordenar la lista por fecha y hora
             data.sort(new Comparator<String[]>() {
                 @Override
                 public int compare(String[] o1, String[] o2) {
                     try {
                         // Usar los índices de columna constantes
                         String fecha1 = o1[COL_FECHA];
                         String hora1 = o1[COL_HORA];
                         String fecha2 = o2[COL_FECHA];
                         String hora2 = o2[COL_HORA];

                         // Usar el formatter de parseo pre-inicializado
                         Date date1 = SDF_PARSE_DATETIME.parse(hora1 + " " + fecha1);
                         Date date2 = SDF_PARSE_DATETIME.parse(hora2 + " " + fecha2);
                        
                         return date2.compareTo(date1); // Ordenar de más reciente a más antiguo
                    
                     } catch (Exception e) {
                         e.printStackTrace();
                         return 0; // Si hay un error, no cambiar el orden
                     }
                 }
             });

             tableModel.setRowCount(0); // Limpia la tabla antes de cargar datos nuevos

             // Agregar las filas en orden a la tabla
             for (String[] row : data) {
                 tableModel.addRow(row);
             }

         } catch (FileNotFoundException e) {
             // Si el archivo no existe, simplemente limpiar la tabla
             tableModel.setRowCount(0); 
             System.out.println("Archivo no encontrado (se creará al guardar): " + e.getMessage());
         } catch (IOException e) {
             JOptionPane.showMessageDialog(this, "Error al cargar el archivo de texto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
         }
     }

     /**
      * Actualiza las etiquetas de Hora y Fecha.
      */
     private void actualizarFechaYHora() {
         Date fechaYHoraMexico = new Date();
        
         // Usar los formatters pre-inicializados
         String horaMexico = FORMATO_HORA.format(fechaYHoraMexico);
         String fechaMexico = FORMATO_FECHA_RELOJ.format(fechaYHoraMexico);

         jlHora.setText(horaMexico);
         jlFecha.setText(fechaMexico);
     }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jtWO = new javax.swing.JTextField();
        jtPanel1 = new javax.swing.JTextField();
        jtPanel2 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jbEnviar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtRegistros = new javax.swing.JTable();
        jlHora = new javax.swing.JLabel();
        jlFecha = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnRegreso = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jtProyecto = new javax.swing.JTextField();
        lblVersion = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Solicitud TURNO 1");

        jtWO.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jtPanel1.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jtPanel2.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel2.setText("WO");

        jLabel3.setText("Panel 1");

        jLabel4.setText("Panel 2");

        jLabel5.setText("Solicitud de alta de seriales ");

        jLabel6.setText("TURNO 1");

        jbEnviar.setText("Enviar");
        jbEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbEnviarActionPerformed(evt);
            }
        });

        jtRegistros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Requiere", "WO", "Panel 1", "Panel 2", "Proyecto", "Hora" , "Fecha", "Estatus", "Comentario", "Atendió"
            }
        ));
        jScrollPane1.setViewportView(jtRegistros);

        jlHora.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlHora.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jlFecha.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlFecha.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setText("Hora");

        jLabel9.setText("Fecha");

        btnRegreso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/re.png"))); // NOI18N
        btnRegreso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresoActionPerformed(evt);
            }
        });

        jLabel10.setText("Proyecto");

        jtProyecto.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(273, 273, 273)
                                        .addComponent(jbEnviar))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jtWO, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jtPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(jtPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(33, 33, 33)
                                                .addComponent(jLabel2)
                                                .addGap(126, 126, 126)
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel4)
                                                .addGap(74, 74, 74)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(24, 24, 24)
                                                .addComponent(jtProyecto, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(50, 50, 50)
                                                .addComponent(jLabel10)))))
                                .addGap(133, 133, 133))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 660, Short.MAX_VALUE)
                                        .addComponent(jLabel6)
                                        .addGap(51, 51, 51))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblVersion, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5)))
                                .addGap(371, 371, 371)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(69, 69, 69)
                                .addComponent(jLabel9)
                                .addGap(19, 19, 19))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jlHora, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jlFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(btnRegreso, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1350, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btnRegreso, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel8)
                                .addComponent(jLabel9))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jlFecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jlHora, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel5))
                            .addComponent(lblVersion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtWO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtProyecto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jbEnviar)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbEnviarActionPerformed
// Obtener los datos (el DocumentFilter ya los convirtió a mayúsculas)
        // Se agrega .toUpperCase() como medida de seguridad adicional.
        String wo = jtWO.getText().trim().toUpperCase();
        String panel1 = jtPanel1.getText().trim().toUpperCase();
        String panel2 = jtPanel2.getText().trim().toUpperCase();
        String proyecto = jtProyecto.getText().trim().toUpperCase();

        // --- Validación ---
        if (wo.isEmpty() || panel1.isEmpty() || panel2.isEmpty() || proyecto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (panel1.equals(panel2)) {
            JOptionPane.showMessageDialog(this, "NO se pueden mandar solicitudes de 1 solo panel (Paneles iguales).", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // --- Procesamiento ---
        
        // Obtener hora y fecha actuales usando los formatters
        Date fechaYHoraMexico = new Date();
        String horaMexico = FORMATO_HORA.format(fechaYHoraMexico);
        String fechaMexico = FORMATO_FECHA_ARCHIVO.format(fechaYHoraMexico); // Usar formato con '/'

        // Crear la cadena de datos
        String datosSolicitud = obtenerNombreUsuarioFormateado() + ";" + wo + ";" + panel1 + ";" + panel2 + ";" + proyecto + ";" + horaMexico + ";" + fechaMexico + ";" + "Abierto" + ";" + "." + ";" + ".";

        // Escribir en el archivo
        try (FileWriter fileWriter = new FileWriter(this.rutaArchivo, true); // Usar la variable de clase
             BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {

            bufferedWriter.write(datosSolicitud);
            bufferedWriter.newLine(); // Agregar una nueva línea

            // Éxito
            JOptionPane.showMessageDialog(this, "Solicitud enviada con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            // Limpiar los campos
            jtWO.setText("");
            jtPanel1.setText("");
            jtPanel2.setText("");
            jtProyecto.setText("");

            // Actualizar la tabla inmediatamente
            cargarArchivoEnJTSolicitudes();

        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al guardar la solicitud.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jbEnviarActionPerformed

private String obtenerNombreUsuarioFormateado() {
        String nombreUsuario = System.getProperty("user.name");
        String[] partes = nombreUsuario.split("\\.");
        StringBuilder nombreFormateado = new StringBuilder();

        for (String parte : partes) {
            if (nombreFormateado.length() > 0) {
                nombreFormateado.append(" "); // Agregar espacio entre nombres
            }
            nombreFormateado.append(capitalizar(parte));
        }

        return nombreFormateado.toString();
    }

private String capitalizar(String palabra) {
        if (palabra == null || palabra.isEmpty()) {
            return palabra;
        }
        return palabra.substring(0, 1).toUpperCase() + palabra.substring(1).toLowerCase();
    }
                                           
    
    private void btnRegresoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresoActionPerformed
        Selec s = new Selec();
        dispose();
    }//GEN-LAST:event_btnRegresoActionPerformed

    // Agrega esto al final de tu constructor turno1() o en un método de inicio
private void iniciarReceptorMensajes() {
    Thread hiloEscucha = new Thread(() -> {
        try {
            DatagramSocket socket = new DatagramSocket(9876); // Mismo puerto que T1
            byte[] buffer = new byte[1024];

            while (true) {
                DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
                socket.receive(paquete); // El programa espera aquí hasta recibir un mensaje
                String recibido = new String(paquete.getData(), 0, paquete.getLength());

                if ("MOSTRAR_AVISO_PROCESOS".equals(recibido)) {
                    // Importante usar SwingUtilities para mostrar el mensaje desde otro hilo
                    SwingUtilities.invokeLater(() -> {
                        JOptionPane.showMessageDialog(this, 
                            "No es necesario llamar al Soporte para dar de alta los seriales.\n" +
                            "Se darán de alta conforme se tenga disponibilidad de los técnicos de procesos.", 
                            "AVISO IMPORTANTE", 
                            JOptionPane.WARNING_MESSAGE);
                    });
                }
            }
        } catch (Exception e) {
            System.err.println("Error en receptor de red: " + e.getMessage());
        }
    });
    hiloEscucha.setDaemon(true); // Para que se cierre al cerrar el programa
    hiloEscucha.start();
}
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(turno1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(turno1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(turno1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(turno1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new turno1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegreso;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbEnviar;
    private javax.swing.JLabel jlFecha;
    private javax.swing.JLabel jlHora;
    private javax.swing.JTextField jtPanel1;
    private javax.swing.JTextField jtPanel2;
    private javax.swing.JTextField jtProyecto;
    private javax.swing.JTable jtRegistros;
    private javax.swing.JTextField jtWO;
    private javax.swing.JLabel lblVersion;
    // End of variables declaration//GEN-END:variables
}
