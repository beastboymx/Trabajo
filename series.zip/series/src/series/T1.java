package series;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;


public class T1 extends javax.swing.JFrame {

    // --- Constantes de Rutas ---
    private static final String RUTA_BASE_SERIALES = "O:\\Department\\SerialesEyD\\";
    private static final String RUTA_SOLICITUDES_T1 = RUTA_BASE_SERIALES + "solicitudesT1.txt";
    private static final String RUTA_SOLICITUDES_T2 = RUTA_BASE_SERIALES + "solicitudesT2.txt";
    private static final String RUTA_SOLICITUDES_T3 = RUTA_BASE_SERIALES + "solicitudesT3.txt";
    private static final String RUTA_REGISTRO_BORRADO = RUTA_BASE_SERIALES + "Programas\\Borrado.txt";
    private static final String RUTA_SCANNER_DIR = "\\\\guad-dsk-001\\GuadTest\\mvp.doc\\Scripts\\Scanner";
    private static final String RUTA_CSV_USUARIO_BASE = RUTA_BASE_SERIALES + System.getProperty("user.name") + "_seriales.csv";
    private static final String RUTA_AVISOS = RUTA_BASE_SERIALES + "avisos.txt";

    // --- Constantes de Estatus ---
    private static final String ESTATUS_ABIERTO = "Abierto";
    private static final String ESTATUS_CERRADO = "Cerrado";
    private static final String ESTATUS_CANCELADO = "Cancelado";
    private static final String ESTATUS_EN_PROCESO = "En Proceso";

    // --- Constantes de Columnas (Indices) ---
    private static final int COL_REQUIERE = 0;
    private static final int COL_WO = 1;
    private static final int COL_PANEL_1 = 2;
    private static final int COL_PANEL_2 = 3;
    private static final int COL_PROYECTO = 4;
    private static final int COL_HORA = 5;
    private static final int COL_FECHA = 6;
    private static final int COL_ESTATUS = 7;
    private static final int COL_COMENTARIO = 8;
    private static final int COL_ATENDIO = 9;

    // --- Variables de instancia ---
    private List<String> linesList = new ArrayList<>();
    private String nombreArchivoCargado = ""; // Variable para almacenar el nombre del archivo cargado
    private DefaultTableModel tableModel;
    // private String archivoTexto = ""; // Esta variable no parecía usarse, considera eliminarla
    private JComboBox<String> estatusComboBox = new JComboBox<>(new String[]{ESTATUS_ABIERTO, ESTATUS_CERRADO, ESTATUS_CANCELADO});
    private boolean avisoMostrado = false; // Variable para controlar la visualización del aviso
    private boolean archivoValido = false; // Nueva variable para verificar validez
    private boolean archivoCargado = false;
    private boolean contrasenaIngresada = false; // Variable para rastrear si se ingresó la contraseña
    private String ultimoErrorCarga = ""; // <-- AÑADE ESTA LÍNEA
    
    public T1() {
    initComponents(); // Dejar esto primero
    configurarVentana();
    configurarTabla();
    registrarListeners();
    iniciarServiciosDeFondo();
            if (lblVersion != null) { // Asume que tienes un JLabel llamado lblVersion
            lblVersion.setText(VersionApp.getTextoVersion());
        }
    cargarArchivoEnJTSolicitudes(); // Carga inicial de datos
    }
    
    @Override
    
    public Image getIconImage(){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("Img/b.png"));
         
         
         return retValue;
    }
    
    private void configurarVentana() {
    setAlwaysOnTop(true);
    setLocationRelativeTo(null);
    setResizable(false);
    setIconImage(getIconImage());
    // ... cualquier otra configuración del JFrame
}
    
private void configurarTabla() {
        // Asignar el tableModel
        tableModel = (DefaultTableModel) jtSolicitudes.getModel();

        // --- Renderers ---

        // Centrar los títulos de las columnas
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);

        // Centrar el contenido de las celdas (Default)
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        // Renderer para texto (color negro por defecto)
        DefaultTableCellRenderer textRenderer = new DefaultTableCellRenderer();
        textRenderer.setForeground(Color.BLACK);
        jtSolicitudes.setDefaultRenderer(Object.class, textRenderer);

        // Asignar renderers a columnas
        for (int i = 0; i < jtSolicitudes.getColumnModel().getColumnCount(); i++) {
            jtSolicitudes.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
            jtSolicitudes.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

// Renderer especial para la columna de Estatus (con colores)
        jtSolicitudes.getColumnModel().getColumn(COL_ESTATUS).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component cellComponent = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                String estatus = (String) value;

                if (ESTATUS_ABIERTO.equals(estatus)) {
                    cellComponent.setBackground(Color.YELLOW);
                } else if (ESTATUS_CANCELADO.equals(estatus)) {
                    cellComponent.setBackground(Color.RED);
                } else if (ESTATUS_CERRADO.equals(estatus)) {
                    cellComponent.setBackground(Color.GREEN);
                
                // --- AÑADE ESTE BLOQUE ---
                } else if (ESTATUS_EN_PROCESO.equals(estatus)) {
                    cellComponent.setBackground(Color.ORANGE); 
                // --- FIN DEL BLOQUE ---
                    
                } else {
                    cellComponent.setBackground(table.getBackground());
                }
                
                setHorizontalAlignment(JLabel.CENTER);
                return cellComponent;
            }
        });

        // --- Configuración de Anchos de Columna ---
        jtSolicitudes.getColumnModel().getColumn(COL_REQUIERE).setPreferredWidth(50);   //Requiere
        jtSolicitudes.getColumnModel().getColumn(COL_WO).setPreferredWidth(30);         //WO
        jtSolicitudes.getColumnModel().getColumn(COL_PANEL_1).setPreferredWidth(100);    //Panel1
        jtSolicitudes.getColumnModel().getColumn(COL_PANEL_2).setPreferredWidth(100);    //Panel2
        jtSolicitudes.getColumnModel().getColumn(COL_PROYECTO).setPreferredWidth(30);   //Proyecto
        jtSolicitudes.getColumnModel().getColumn(COL_HORA).setPreferredWidth(30);       //Hora
        jtSolicitudes.getColumnModel().getColumn(COL_FECHA).setPreferredWidth(30);      //Fecha
        jtSolicitudes.getColumnModel().getColumn(COL_ESTATUS).setPreferredWidth(20);    //Status
        jtSolicitudes.getColumnModel().getColumn(COL_COMENTARIO).setPreferredWidth(250); //Comentario
        jtSolicitudes.getColumnModel().getColumn(COL_ATENDIO).setPreferredWidth(50);    //Atiendio

        // --- Grid y Sorter ---
        jtSolicitudes.setShowGrid(true);
        jtSolicitudes.setGridColor(java.awt.Color.BLACK);
        jtSolicitudes.setShowHorizontalLines(true);
        jtSolicitudes.setShowVerticalLines(true);

        // Crear un TableRowSorter y asignarlo a la tabla (para deshabilitar ordenamiento)
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(tableModel) {
            @Override
            public void toggleSortOrder(int column) {
                // No hacer nada al intentar ordenar
            }
        };
        jtSolicitudes.setRowSorter(sorter);
    }

private void registrarListeners() {
        // KeyListeners para jtinicio (solo números y letras)
        jtinicio.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetterOrDigit(c)) {
                    e.consume(); // Elimina caracteres no válidos
                }
            }
        });

        // KeyListeners para jtFin (solo números y letras)
        jtFin.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetterOrDigit(c)) {
                    e.consume(); // Elimina caracteres no válidos
                }
            }
        });

        // FocusListeners para jtinicio (trim)
        jtinicio.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                jtinicio.setText(jtinicio.getText().trim());
            }
        });

        // FocusListeners para jtFin (trim)
        jtFin.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                jtFin.setText(jtFin.getText().trim());
            }
        });

        // KeyListener para jtArchivo (Enter)
        jtArchivo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    if (jtArchivo.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(T1.this, "No se ha cargado el archivo", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        cargarArchivo();
                        archivoCargado = true; // Marcar como archivo cargado
                    }
                }
            }
        });

jbEdiar.addActionListener(new ActionListener() {
@Override
    public void actionPerformed(ActionEvent e) {
        int selectedRow = jtSolicitudes.getSelectedRow();

        if (selectedRow >= 0) {
            int modelRow = jtSolicitudes.convertRowIndexToModel(selectedRow);

            final String refWO = tableModel.getValueAt(modelRow, COL_WO).toString();
            final String refP1 = tableModel.getValueAt(modelRow, COL_PANEL_1).toString();
            final String refP2 = tableModel.getValueAt(modelRow, COL_PANEL_2).toString();
            final String refH = tableModel.getValueAt(modelRow, COL_HORA).toString();
            final String refF = tableModel.getValueAt(modelRow, COL_FECHA).toString();

            String estatusActual = tableModel.getValueAt(modelRow, COL_ESTATUS).toString();
            String comentarioActual = tableModel.getValueAt(modelRow, COL_COMENTARIO).toString();

            // --- COMPONENTES CENTRADOS Y SIN "EN PROCESO" ---
            String[] opcionesEstatus = {ESTATUS_ABIERTO, ESTATUS_CERRADO, ESTATUS_CANCELADO};
            JComboBox<String> comboEstatus = new JComboBox<>(opcionesEstatus);
            comboEstatus.setSelectedItem(estatusActual);
            ((JLabel)comboEstatus.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER); // Centrar Texto Combo

            JTextField comentarioField = new JTextField(comentarioActual);
            comentarioField.setHorizontalAlignment(JTextField.CENTER); // Centrar Texto Field

            // Lógica automática para el "OK"
            comboEstatus.addActionListener(al -> {
                String seleccionado = (String) comboEstatus.getSelectedItem();
                if (ESTATUS_CERRADO.equals(seleccionado)) {
                    comentarioField.setText("OK");
                } else if (ESTATUS_ABIERTO.equals(seleccionado)) {
                    comentarioField.setText(""); 
                }
            });

            if (ESTATUS_CERRADO.equals(estatusActual) && comentarioActual.trim().isEmpty()) {
                comentarioField.setText("OK");
            }

            JTextField atendioField = new JTextField(obtenerNombreUsuarioFormateado());
            atendioField.setEditable(false);
            atendioField.setHorizontalAlignment(JTextField.CENTER); // Centrar Texto Atendió

            Object[] editFields = {
                "Estatus:", comboEstatus,
                "Comentario:", comentarioField,
                "Atendió:", atendioField
            };

            int result = JOptionPane.showConfirmDialog(T1.this, editFields, 
                    "Finalizar Solicitud - WO: " + refWO, 
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                int actualModelRow = -1;
                for (int i = 0; i < tableModel.getRowCount(); i++) {
                    if (tableModel.getValueAt(i, COL_WO).equals(refWO) &&
                        tableModel.getValueAt(i, COL_PANEL_1).equals(refP1) &&
                        tableModel.getValueAt(i, COL_PANEL_2).equals(refP2) &&
                        tableModel.getValueAt(i, COL_HORA).equals(refH) &&
                        tableModel.getValueAt(i, COL_FECHA).equals(refF)) {
                        actualModelRow = i;
                        break;
                    }
                }

                if (actualModelRow == -1) {
                    JOptionPane.showMessageDialog(T1.this, "Error de sincronización.");
                    return;
                }

                String nuevoEstatus = comboEstatus.getSelectedItem().toString();
                String nuevoComentario = comentarioField.getText().trim();

                if ((ESTATUS_CERRADO.equals(nuevoEstatus) || ESTATUS_CANCELADO.equals(nuevoEstatus)) && nuevoComentario.isEmpty()) {
                    JOptionPane.showMessageDialog(T1.this, "El comentario es obligatorio.");
                    return;
                }

                tableModel.setValueAt(nuevoEstatus, actualModelRow, COL_ESTATUS);
                tableModel.setValueAt(nuevoComentario, actualModelRow, COL_COMENTARIO);
                tableModel.setValueAt(atendioField.getText(), actualModelRow, COL_ATENDIO); 

                actualizarArchivoTextoDesdeTabla();
            }
        }
    }
});

        // ListSelectionListener para la tabla (para rellenar campos)
        jtSolicitudes.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
@Override
    public void valueChanged(ListSelectionEvent e) {
        // getValueIsAdjusting evita que se ejecute dos veces por un solo click
        if (!e.getValueIsAdjusting()) {
            int selectedRow = jtSolicitudes.getSelectedRow();
            
            // Solo actualizar campos si la selección es válida y no es -1
            if (selectedRow >= 0) {
                try {
                    String wo = jtSolicitudes.getValueAt(selectedRow, COL_WO).toString();
                    String panel1 = jtSolicitudes.getValueAt(selectedRow, COL_PANEL_1).toString();
                    String panel2 = jtSolicitudes.getValueAt(selectedRow, COL_PANEL_2).toString();

                    jtArchivo.setText(wo);
                    jtinicio.setText(panel1);
                    jtFin.setText(panel2);
                } catch (Exception ex) {
                    // Prevenir errores si la fila se borra justo en el momento del click
                }
            }
        }
    }
});

        // MouseListener para el Header (para deshabilitar ordenamiento)
        JTableHeader header = jtSolicitudes.getTableHeader();
        header.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // No hacer nada al hacer clic en el encabezado
            }
        });
    }

private void iniciarServiciosDeFondo() {
        iniciarMonitoreoArchivo();
        //iniciarTimerBorradoDiario();
    }

/*private void iniciarTimerBorradoDiario() {
    javax.swing.Timer timerVerificadorHora = new javax.swing.Timer(60000, e -> {
// Esto usa la hora que ves en el reloj de la barra de tareas de Windows
LocalDateTime fechaHoraActual = LocalDateTime.now(); 
String horaActual = fechaHoraActual.format(DateTimeFormatter.ofPattern("HH:mm"));

        // Hora de borrado para T1 (2 PM)
        final String HORA_BORRADO_T1 = "14:00"; 

        if (HORA_BORRADO_T1.equals(horaActual)) {
            if (!avisoMostrado) { 
                transferirAbiertosYLimpiar(RUTA_SOLICITUDES_T1, RUTA_SOLICITUDES_T2); 

                SwingUtilities.invokeLater(() -> {
                    JOptionPane pane = new JOptionPane("Solicitudes abiertas transferidas al Turno 2.\nArchivo T1 limpiado.",
                                                         JOptionPane.INFORMATION_MESSAGE,
                                                         JOptionPane.DEFAULT_OPTION,
                                                         null, new Object[]{"OK"});
                    JDialog dialog = pane.createDialog(T1.this, "Transferencia T1 -> T2 Completada");
                    dialog.setLocationRelativeTo(null); 
                    dialog.setModal(false); 
                    dialog.setVisible(true);
                });

                avisoMostrado = true; 
            }
        } else {
            avisoMostrado = false;
        }
    });
    timerVerificadorHora.setInitialDelay(5000);
    timerVerificadorHora.start();
}*/

        private void iniciarMonitoreoArchivo() {
        Thread hiloMonitoreo = new Thread(() -> {
            try {
                Path path = Paths.get("O:\\Department\\SerialesEyD\\solicitudesT1.txt");
                WatchService watchService = FileSystems.getDefault().newWatchService();
                path.getParent().register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);
                while (true) {
                    WatchKey key = watchService.take();
                    for (WatchEvent<?> event : key.pollEvents()) {
                        if (event.context().toString().equals("solicitudesT1.txt")) {
                            // Se detectó un cambio en el archivo
                            SwingUtilities.invokeLater(() -> cargarArchivoEnJTSolicitudes()); // Actualiza la tabla en el hilo de la interfaz
                        }
                    }
                    key.reset();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        hiloMonitoreo.setDaemon(true); // Hacer que el hilo sea un hilo de fondo
        hiloMonitoreo.start(); // Inicia el hilo de monitoreo
    }
        

    @SuppressWarnings("unchecked")
   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnRegreso = new javax.swing.JButton();
        jtinicio = new javax.swing.JTextField();
        jtFin = new javax.swing.JTextField();
        jbGenerar = new javax.swing.JButton();
        jtArchivo = new javax.swing.JTextField();
        jlCantidad = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtSolicitudes = new javax.swing.JTable();
        jbEdiar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jbSeriales = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jbBorrar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        lblVersion = new javax.swing.JLabel();
        jlCantidadSolicitudes = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        btnRegreso.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/re.png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("AltaSeriales TURNO 1");

        jtinicio.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jtFin.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jbGenerar.setText("Generar CSV");
        jbGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbGenerarActionPerformed(evt);
            }
        });

        jtArchivo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jtArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtArchivoActionPerformed(evt);
            }
        });
        jtArchivo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jtArchivoKeyPressed(evt);
            }
        });

        jlCantidad.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jlCantidad.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setText("Número  de panel");

        jLabel2.setText("Número  de panel");

        jLabel3.setText("Número de orden");

        jLabel4.setText("Información");

        jtSolicitudes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
            },
            new String [] {
                "Requiere", "WO", "Panel 1", "Panel 2", "Proyecto", "Hora" , "Fecha", "Estatus", "Comentario", "Atendió"
            }
        ));
        jScrollPane1.setViewportView(jtSolicitudes);

        jbEdiar.setText("Editar");
        jbEdiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbEdiarActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/re.png"))); // NOI18N
        jButton1.setBorder(null);
        jButton1.setBorderPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jbSeriales.setText("Ruta Seriales");
        jbSeriales.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbSerialesActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/inf.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jbBorrar.setText("Borrar");
        jbBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbBorrarActionPerformed(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Img/P.png"))); // NOI18N

        lblVersion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jlCantidadSolicitudes.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jlCantidadSolicitudes.setText("Cantidad de Solicitudes:");

        jButton3.setText("Aviso");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addGap(655, 655, 655))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jlCantidadSolicitudes, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(484, 484, 484)
                        .addComponent(lblVersion, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jbSeriales)
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jbBorrar)
                                                .addGap(18, 18, 18)
                                                .addComponent(jButton3)
                                                .addGap(238, 238, 238)
                                                .addComponent(jlCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGap(0, 322, Short.MAX_VALUE)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jtinicio, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGroup(layout.createSequentialGroup()
                                                                .addGap(44, 44, 44)
                                                                .addComponent(jLabel2)))
                                                        .addGap(105, 105, 105)
                                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jtFin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                                .addComponent(jLabel1)
                                                                .addGap(45, 45, 45)))
                                                        .addGap(381, 381, 381))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                        .addComponent(jLabel3)
                                                        .addGap(562, 562, 562))))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jbEdiar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jScrollPane1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(560, 560, 560)
                                .addComponent(jtArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(632, 632, 632)
                                .addComponent(jbGenerar)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblVersion, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jbSeriales)
                                    .addComponent(jbBorrar)
                                    .addComponent(jButton3)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel3))
                                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jtArchivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(31, 31, 31)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel2)
                                                .addGap(2, 2, 2)
                                                .addComponent(jtinicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel1)
                                                .addGap(2, 2, 2)
                                                .addComponent(jtFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(18, 18, 18)
                                        .addComponent(jbGenerar)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jlCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(161, 161, 161)
                                        .addComponent(jbEdiar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jlCantidadSolicitudes)))))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void cargarArchivoEnJTSolicitudes() {
    File f = new File(RUTA_SOLICITUDES_T1); // Cambiar a T2 o T3 según corresponda
    if (!f.exists()) return;

    // --- PASO A: RESPALDAR LA SELECCIÓN ACTUAL ---
    int selectedRow = jtSolicitudes.getSelectedRow();
    String woRespaldada = null, horaRespaldada = null, fechaRespaldada = null;
    
    if (selectedRow >= 0) {
        int modelRow = jtSolicitudes.convertRowIndexToModel(selectedRow);
        woRespaldada = tableModel.getValueAt(modelRow, COL_WO).toString();
        horaRespaldada = tableModel.getValueAt(modelRow, COL_HORA).toString();
        fechaRespaldada = tableModel.getValueAt(modelRow, COL_FECHA).toString();
    }

    try (BufferedReader br = new BufferedReader(new FileReader(f))) {
        List<String[]> data = new ArrayList<>();
        String line;
        while ((line = br.readLine()) != null) {
            if (!line.trim().isEmpty()) data.add(line.split(";", -1));
        }

        // Ordenamiento
        data.sort((o1, o2) -> {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a dd/MM/yyyy");
                return sdf.parse(o2[COL_HORA] + " " + o2[COL_FECHA]).compareTo(sdf.parse(o1[COL_HORA] + " " + o1[COL_FECHA]));
            } catch (Exception e) { return 0; }
        });

        // --- PASO B: ACTUALIZACIÓN INTELIGENTE (Para no perder el foco) ---
        if (tableModel.getRowCount() != data.size()) {
            tableModel.setRowCount(0);
            for (String[] r : data) tableModel.addRow(r);
        } else {
            for (int i = 0; i < data.size(); i++) {
                for (int j = 0; j < data.get(i).length; j++) {
                    Object actual = tableModel.getValueAt(i, j);
                    if (actual == null || !actual.toString().equals(data.get(i)[j])) {
                        tableModel.setValueAt(data.get(i)[j], i, j);
                    }
                }
            }
        }

        // --- PASO C: RESTAURAR LA SELECCIÓN EXACTA ---
        if (woRespaldada != null) {
            for (int i = 0; i < jtSolicitudes.getRowCount(); i++) {
                String rowWO = jtSolicitudes.getValueAt(i, COL_WO).toString();
                String rowH = jtSolicitudes.getValueAt(i, COL_HORA).toString();
                String rowF = jtSolicitudes.getValueAt(i, COL_FECHA).toString();
                
                if (rowWO.equals(woRespaldada) && rowH.equals(horaRespaldada) && rowF.equals(fechaRespaldada)) {
                    jtSolicitudes.setRowSelectionInterval(i, i);
                    // Desplazar el scroll hacia la fila si es necesario
                    jtSolicitudes.scrollRectToVisible(jtSolicitudes.getCellRect(i, 0, true));
                    break;
                }
            }
        }
        
        if (jlCantidadSolicitudes != null) jlCantidadSolicitudes.setText("Cantidad de Solicitudes: " + data.size());
    } catch (IOException e) { e.printStackTrace(); }
}

private void actualizarArchivoTextoDesdeTabla() {
    // Usar la constante de la clase T1
    String rutaArchivo = RUTA_SOLICITUDES_T1; 

    // Asegurarse de que tableModel no sea nulo
    if (tableModel == null) {
         System.err.println("tableModel es nulo al intentar guardar.");
         JOptionPane.showMessageDialog(this, "interno: Modelo de tabla no disponible.", "Error", JOptionPane.ERROR_MESSAGE);
         return;
    }

    // Usar try-with-resources para asegurar que el writer se cierre
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo, false))) { // false para SOBRESCRIBIR
        
        // Iterar por CADA fila del MODELO de la tabla
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            StringBuilder line = new StringBuilder();
            // Iterar por CADA columna de la fila actual
            for (int j = 0; j < tableModel.getColumnCount(); j++) {
                Object cellValue = tableModel.getValueAt(i, j);
                
                // Añadir el valor de la celda (o cadena vacía si es nulo)
                line.append(cellValue != null ? cellValue.toString() : ""); 
                
                // Añadir el separador ';' si no es la última columna
                if (j < tableModel.getColumnCount() - 1) {
                    line.append(";");
                }
            }
            // Escribir la línea construida en el archivo
            writer.write(line.toString());
            writer.newLine(); // Añadir salto de línea
        }

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error CRÍTICO al guardar el archivo:\n" + rutaArchivo + "\n" + e.getMessage(),
                                      "Error de Escritura", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace(); 
    } catch (Exception e) { // Capturar otros posibles errores (ej. seguridad)
         JOptionPane.showMessageDialog(this, "Error inesperado al guardar el archivo:\n" + e.getMessage(),
                                       "Error Inesperado", JOptionPane.ERROR_MESSAGE);
         e.printStackTrace();
    }
}
    
    private void jbGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbGenerarActionPerformed
int selectedRow = jtSolicitudes.getSelectedRow(); 

    // 1. VALIDACIÓN INICIAL DE SELECCIÓN
    if (selectedRow < 0) {
        JOptionPane.showMessageDialog(T1.this, "Por favor, selecciona una solicitud de la tabla.", "Selección Requerida", JOptionPane.WARNING_MESSAGE);
        return; 
    }

    int modelRow = jtSolicitudes.convertRowIndexToModel(selectedRow); 
    
    // CAPTURAR "HUELLA DIGITAL" PARA CONTENCIÓN DE DUPLICADOS
    final String refWO = tableModel.getValueAt(modelRow, COL_WO).toString();
    final String refP1 = tableModel.getValueAt(modelRow, COL_PANEL_1).toString();
    final String refP2 = tableModel.getValueAt(modelRow, COL_PANEL_2).toString();
    final String refH = tableModel.getValueAt(modelRow, COL_HORA).toString();
    final String refF = tableModel.getValueAt(modelRow, COL_FECHA).toString();
    String estatusActual = tableModel.getValueAt(modelRow, COL_ESTATUS).toString();

    // 2. CONDICIÓN: NO PROCESAR SI YA ESTÁ CERRADO O CANCELADO (Evitar retrabajo innecesario)
    if (ESTATUS_CERRADO.equals(estatusActual)) {
        JOptionPane.showMessageDialog(T1.this, "Esta solicitud ya fue finalizada (Cerrada).", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        return;
    }

    // 3. VALIDACIONES DE DATOS (Las que ya tenías)
    if (refWO.trim().isEmpty() || refP1.trim().isEmpty() || refP2.trim().isEmpty()) {
        JOptionPane.showMessageDialog(T1.this, "Error: La fila tiene datos de paneles incompletos.", "Error en Fila", JOptionPane.ERROR_MESSAGE);
        return;
    }
    if (refWO.trim().length() != 8) {
         JOptionPane.showMessageDialog(T1.this, "La WO debe tener exactamente 8 dígitos.", "Error en WO", JOptionPane.ERROR_MESSAGE);
         return;
    }

    // 4. MARCADO VISUAL "EN PROCESO"
    String usuarioLogueado = obtenerNombreUsuarioFormateado();
    tableModel.setValueAt(ESTATUS_EN_PROCESO, modelRow, COL_ESTATUS);
    tableModel.setValueAt(usuarioLogueado, modelRow, COL_ATENDIO);
    
    // Sincronizar campos superiores
    jtArchivo.setText(refWO);
    jtinicio.setText(refP1);
    jtFin.setText(refP2);

    // Guardar cambio de estatus en el servidor inmediatamente
    actualizarArchivoTextoDesdeTabla(); 
    jbGenerar.setEnabled(false); // Bloqueo de seguridad para el botón

    // 5. TIMER PARA VISIBILIDAD Y PROCESAMIENTO
    Timer delayTimer = new Timer(600, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            ((Timer)e.getSource()).stop();

            // RE-LOCALIZAR FILA EXACTA (Por si alguien más agregó líneas al TXT)
            int actualRow = -1;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (tableModel.getValueAt(i, COL_WO).equals(refWO) && 
                    tableModel.getValueAt(i, COL_PANEL_1).equals(refP1) &&
                    tableModel.getValueAt(i, COL_PANEL_2).equals(refP2) &&
                    tableModel.getValueAt(i, COL_HORA).equals(refH) &&
                    tableModel.getValueAt(i, COL_FECHA).equals(refF)) {
                    actualRow = i;
                    break;
                }
            }

            if (actualRow != -1) {
                // 6. EJECUTAR LÓGICA DE CARGA Y EXTRACCIÓN
                if (cargarArchivo()) { 
                    int lineasGeneradas = generarCSV(actualRow, refWO);

                    if (lineasGeneradas >= 0) { 
                        // FLUJO SOLICITADO: Se mantiene "En Proceso" con aviso de éxito
                        tableModel.setValueAt(ESTATUS_EN_PROCESO, actualRow, COL_ESTATUS);
                        
                        actualizarArchivoTextoDesdeTabla(); 
                        
                        
                        // Limpiar campos de entrada para el siguiente uso
                        jtArchivo.setText(refWO);
                        jlCantidad.setText("Cantidad Seriales: " + lineasGeneradas + " | WO: " + refWO);
                        
                        JOptionPane.showMessageDialog(T1.this, "Archivo CSV se ha generado", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }
                    // Si generarCSV falla, registrarFalla ya lo pone en "Cancelado"
                } else {
                    // Si no se encuentra el archivo en Scanner
                    registrarFallaEnTabla(actualRow, ultimoErrorCarga); 
                }
            } else {
                JOptionPane.showMessageDialog(T1.this, "Error: No se pudo localizar la fila original tras la actualización.");
            }
            
            jbGenerar.setEnabled(true); // Reactivar botón
        }
    });
    delayTimer.start();
    }//GEN-LAST:event_jbGenerarActionPerformed

    private void jtArchivoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtArchivoKeyPressed
    if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
        if (jtArchivo.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Llena el campo de número de orden.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            cargarArchivo();
        }
    }
    }//GEN-LAST:event_jtArchivoKeyPressed

    private void jbEdiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbEdiarActionPerformed

    }//GEN-LAST:event_jbEdiarActionPerformed

    private void jbSerialesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbSerialesActionPerformed
         try{
            Desktop.getDesktop().open(new File("\\\\guad-dsk-001\\GuadTest\\mvp.doc\\Scripts\\Scanner"));
        }catch(IOException ex){
        }
    }//GEN-LAST:event_jbSerialesActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JOptionPane.showMessageDialog(this, "     Program Created by " + "\n" + "          Oscar Lopez" + "\n" + "\n" +"               Contact" + "\n" + "Oscar.Lopez@plexus.com");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jbBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbBorrarActionPerformed
     borrarContenidoArchivo();
    }//GEN-LAST:event_jbBorrarActionPerformed

    private void jtArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtArchivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtArchivoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Selec s = new Selec();
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
try (BufferedWriter writer = new BufferedWriter(new FileWriter(RUTA_AVISOS))) {
        // Escribimos un "trigger" o disparador
        writer.write("MOSTRAR_ALERTA");
        JOptionPane.showMessageDialog(this, "Aviso enviado correctamente.");
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al crear el aviso: " + e.getMessage());
    }
    }
    
private void jbBotonAvisoActionPerformed(java.awt.event.ActionEvent evt) {
    }//GEN-LAST:event_jButton3ActionPerformed

private boolean cargarArchivo() {
    ultimoErrorCarga = ""; // Limpiar error anterior
    
    // --- NUEVA VALIDACIÓN DE LONGITUD ---
    // (Protección extra, aunque jbGenerarActionPerformed ya debería haber validado)
    if (jtArchivo.getText().length() < 8) {
        ultimoErrorCarga = "WO inválida (menos de 8 caracteres).";
        JOptionPane.showMessageDialog(this, ultimoErrorCarga, "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    // --- FIN VALIDACIÓN ---

    String nombreArchivoBuscar = jtArchivo.getText().substring(0, 8);
    File directory = new File(RUTA_SCANNER_DIR);
    File[] files = directory.listFiles();
    int count = 0;
    File foundFile = null; 

    if (files != null) {
        for (File file : files) {
            if (file.isFile() && file.getName().startsWith(nombreArchivoBuscar)) {
                count++;
                foundFile = file; 
                if (count > 1) {
                    ultimoErrorCarga = "Hay más de un archivo con la misma WO."; // Guardar error
                    JOptionPane.showMessageDialog(this, ultimoErrorCarga, "Error", JOptionPane.ERROR_MESSAGE);
                    // Ya no registra falla
                    jtArchivo.setText(null); jtinicio.setText(null); jtFin.setText(null); jlCantidad.setText(null);
                    return false;
                }
            }
        }
    } else {
         ultimoErrorCarga = "Error al acceder al directorio del scanner.";
         JOptionPane.showMessageDialog(this, ultimoErrorCarga, "Error de Red/Permisos", JOptionPane.ERROR_MESSAGE);
         return false;
    }

    if (count == 0) { // No encontrado
        ultimoErrorCarga = "WO NO ENCONTRADA!"; // Guardar error
        JOptionPane.showMessageDialog(this, ultimoErrorCarga, "ERROR", JOptionPane.ERROR_MESSAGE);
        return false; // Ya no registra falla
    }

    // Si count == 1 y foundFile no es nulo
    try (BufferedReader reader = new BufferedReader(new FileReader(foundFile))) {
        linesList.clear();
        String line;
        while ((line = reader.readLine()) != null) {
            linesList.add(line);
        }
        nombreArchivoCargado = foundFile.getName();
        jtArchivo.setText(foundFile.getName());
        archivoCargado = true;
        return true; // Éxito
    } catch (IOException e) {
        ultimoErrorCarga = "Error al cargar el archivo: " + e.getMessage(); // Guardar error
        JOptionPane.showMessageDialog(this, ultimoErrorCarga, "Error", JOptionPane.ERROR_MESSAGE);
        return false;
    }
}


private int generarCSV(int modelRow, String woActual) {
    try {
        String inicioText = jtinicio.getText().trim(); 
        String finText = jtFin.getText().trim();
        int inicioIndex = -1;
        int finIndex = -1;

        // (Validaciones ya hechas en jbGenerarActionPerformed)

        // Buscar los índices de inicio y fin en linesList
        for (int i = 0; i < linesList.size(); i++) {
            String line = linesList.get(i);
             if (line == null) continue;
            String[] parts = line.split(",");

            if (parts.length >= 6) {
                String dataAfterFifthComma = parts[5].trim();
                if (dataAfterFifthComma.equals(inicioText)) {
                    inicioIndex = i;
                }
                if (dataAfterFifthComma.equals(finText)) {
                    finIndex = i;
                }
                if (inicioIndex != -1 && finIndex != -1) {
                    break;
                }
            }
        }

        // --- MANEJO DE ERROR: ÍNDICES NO ENCONTRADOS ---
        if (inicioIndex == -1 || finIndex == -1) {
            String errorMessage = "No se encontro ";
            if (inicioIndex == -1 && finIndex == -1) {
                errorMessage += "el panel inicial ni el panel final en el archivo.";
            } else if (inicioIndex == -1) {
                errorMessage += "el panel inicial en el archivo.";
            } else { // finIndex == -1
                errorMessage += "el panel final en el archivo.";
            }
            JOptionPane.showMessageDialog(this, errorMessage, "Error de Panel", JOptionPane.ERROR_MESSAGE);
            
            // *** CORRECCIÓN: Usar modelRow ***
            registrarFallaEnTabla(modelRow, errorMessage); 
            
            return -1; // <-- DEVOLVER FALLO
        }

        // Obtener el rango de líneas a procesar
        int startIndex = Math.min(inicioIndex, finIndex);
        int endIndex = Math.max(inicioIndex, finIndex);
        List<String> linesInRange = linesList.subList(startIndex, endIndex + 1);

        File outputFile = new File(RUTA_CSV_USUARIO_BASE);
        int linesWritten = 0;

        // Escribir en el archivo CSV
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            boolean warnedAboutShortData = false;
            for (String line : linesInRange) {
                 if (line == null) continue;
                String[] parts = line.split(",");
                boolean validDataInLine = true; 

                for (String part : parts) {
                     if (part == null) continue;
                    String trimmedPart = part.trim();
                    int equalsIndex = trimmedPart.indexOf("=");

                    if (equalsIndex != -1) {
                        String data = trimmedPart.substring(equalsIndex + 1);

                        if (!data.contains("{")) {
                            if (data.length() >= 5) {
                                writer.write(data);
                                writer.newLine();
                                linesWritten++;
                            } else if (!data.isEmpty()) { 
                                validDataInLine = false; 
                            }
                        }
                    }
                }

                if (!validDataInLine && !warnedAboutShortData) {
                     JOptionPane.showMessageDialog(this,
                         "Advertencia: Se encontró al menos un dato con menos de 5 caracteres. No se incluirá en el CSV.",
                         "Advertencia de Datos Cortos", JOptionPane.WARNING_MESSAGE);
                     warnedAboutShortData = true;
                 }
            }

            if (linesWritten > 0) {
                 return linesWritten; // <-- DEVOLVER ÉXITO (Cantidad)
            } else {
                 String noDataMsg = "No se encontraron datos válidos (>= 5 caracteres, sin '{') entre los paneles especificados.";
                 JOptionPane.showMessageDialog(this, noDataMsg, "CSV Vacío", JOptionPane.WARNING_MESSAGE);
                 
                 // *** CORRECCIÓN: Usar modelRow ***
                 registrarFallaEnTabla(modelRow, "No se encontraron datos válidos para CSV.");
                 
                 return -1; // <-- DEVOLVER FALLO
            }

        } catch (IOException e) {
            String ioErrorMsg = "Error Crítico al escribir el archivo CSV: " + e.getMessage();
            JOptionPane.showMessageDialog(this, ioErrorMsg, "Error de Escritura", JOptionPane.ERROR_MESSAGE);
            
             // *** CORRECCIÓN: Usar modelRow ***
             registrarFallaEnTabla(modelRow, ioErrorMsg);

             return -1; // <-- DEVOLVER FALLO
        }

    } catch (Exception e) { 
         String generalErrorMsg = "Error inesperado al generar CSV: " + e.getMessage();
         JOptionPane.showMessageDialog(this, generalErrorMsg, "Error Inesperado", JOptionPane.ERROR_MESSAGE);
         e.printStackTrace();
         
         // *** CORRECCIÓN: Usar modelRow ***
         registrarFallaEnTabla(modelRow, "Error inesperado: " + e.getClass().getSimpleName());

         return -1; // <-- DEVOLVER FALLO
    } finally {
        // Limpieza final
        archivoCargado = false;
        nombreArchivoCargado = null;
        linesList.clear();
    }
}

private int contarDatosCSV(String archivoCSV) {
        int contador = 0;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(archivoCSV));
            while (reader.readLine() != null) {
                contador++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return contador;
    }

// Método para formatear el nombre de usuario
private String obtenerNombreUsuarioFormateado() {
    String nombreUsuario = System.getProperty("user.name");
    String[] partes = nombreUsuario.split("\\.");
    StringBuilder nombreFormateado = new StringBuilder();
    
    for (String parte : partes) {
        if (nombreFormateado.length() > 0) {
            nombreFormateado.append(" "); // Agregar espacio entre nombres
        }
        nombreFormateado.append(capitalizar(parte));
    }
    
    return nombreFormateado.toString();
}

// Método para capitalizar la primera letra de una palabra
private String capitalizar(String palabra) {
    if (palabra == null || palabra.isEmpty()) {
        return palabra;
    }
    return palabra.substring(0, 1).toUpperCase() + palabra.substring(1).toLowerCase();
}

private void borrarContenidoArchivo() {
    // Usa las constantes de ruta
    try (BufferedWriter writer1 = new BufferedWriter(new FileWriter(RUTA_SOLICITUDES_T1));) {
        // Simplemente no escribimos nada para borrar el contenido
        cargarArchivoEnJTSolicitudes();
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al borrar el contenido del archivo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void registrarFallaEnTabla(int modelRow, String mensajeError) {
    // Seguridad: verificar que el índice sea válido
    if (modelRow < 0 || modelRow >= tableModel.getRowCount()) {
         System.err.println("Error al registrar falla: modelRow " + modelRow + " está fuera de límites.");
         return; 
    }
    
    String nombreUsuario = obtenerNombreUsuarioFormateado();

    // Actualizar el modelo y GUARDAR en el Hilo de Eventos (EDT)
    SwingUtilities.invokeLater(() -> {
        // 1. Actualizar el modelo de la tabla
        tableModel.setValueAt(ESTATUS_CANCELADO, modelRow, COL_ESTATUS);
        tableModel.setValueAt(mensajeError, modelRow, COL_COMENTARIO);
        tableModel.setValueAt(nombreUsuario, modelRow, COL_ATENDIO);
        
        // 2. Notificar a la UI que la fila cambió
        tableModel.fireTableRowsUpdated(modelRow, modelRow);
        
        // 3. *** CORRECCIÓN: Guardar en el archivo DESPUÉS de actualizar la tabla ***
        actualizarArchivoTextoDesdeTabla(); 
    });
}

private void transferirAbiertosYLimpiar(String rutaArchivoOrigen, String rutaArchivoDestino) {
    List<String> lineasAbiertas = new ArrayList<>();

    // --- Paso 1: Leer el archivo de origen y encontrar líneas abiertas ---
    try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivoOrigen))) {
        String linea;
        while ((linea = reader.readLine()) != null) {
            if (!linea.trim().isEmpty()) {
                String[] datos = linea.split(";", -1); // Incluir campos vacíos
                // Verificar si tiene suficientes columnas y si el estatus es "Abierto"
                if (datos.length > COL_ESTATUS && ESTATUS_ABIERTO.equals(datos[COL_ESTATUS].trim())) {
                    lineasAbiertas.add(linea); // Guardar la línea completa
                }
            }
        }
    } catch (FileNotFoundException e) {
        // Si el archivo origen no existe, no hay nada que transferir. No es un error crítico.
        System.out.println("Archivo origen no encontrado para transferencia: " + rutaArchivoOrigen);
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al leer el archivo origen para transferir:\n" + rutaArchivoOrigen + "\n" + e.getMessage(),
                                      "Error de Lectura", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
        return; // No continuar si hubo error de lectura
    }

    // --- Paso 2: Añadir las líneas abiertas al archivo de destino ---
    if (!lineasAbiertas.isEmpty()) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivoDestino, true))) { // true para añadir (append)
            for (String lineaAbierta : lineasAbiertas) {
                writer.write(lineaAbierta);
                writer.newLine();
            }
            System.out.println("Se transfirieron " + lineasAbiertas.size() + " solicitudes abiertas de "
                               + Paths.get(rutaArchivoOrigen).getFileName() + " a " + Paths.get(rutaArchivoDestino).getFileName());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al escribir en el archivo destino:\n" + rutaArchivoDestino + "\n" + e.getMessage(),
                                          "Error de Escritura", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            // Considera si deberías detener el borrado aquí o continuar
            // return; // Podrías descomentar esto si prefieres no borrar si falla la escritura
        }
    } else {
         System.out.println("No se encontraron solicitudes abiertas para transferir desde: " + Paths.get(rutaArchivoOrigen).getFileName());
    }

    // --- Paso 3: Limpiar el archivo de origen ---
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivoOrigen))) {
        writer.write(""); // Sobrescribir con vacío para limpiar
        System.out.println("Archivo origen limpiado: " + Paths.get(rutaArchivoOrigen).getFileName());
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al limpiar el archivo origen:\n" + rutaArchivoOrigen + "\n" + e.getMessage(),
                                      "Error de Escritura", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    
    // --- Paso 4: Recargar la tabla para reflejar el cambio (archivo limpiado) ---
    // Asegurarse de que esto se ejecute en el hilo de Swing si es necesario
    SwingUtilities.invokeLater(this::cargarArchivoEnJTSolicitudes);
}
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(T1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(T1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(T1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(T1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new T1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegreso;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbBorrar;
    private javax.swing.JButton jbEdiar;
    private javax.swing.JButton jbGenerar;
    private javax.swing.JButton jbSeriales;
    private javax.swing.JLabel jlCantidad;
    private javax.swing.JLabel jlCantidadSolicitudes;
    private javax.swing.JTextField jtArchivo;
    private javax.swing.JTextField jtFin;
    private javax.swing.JTable jtSolicitudes;
    private javax.swing.JTextField jtinicio;
    private javax.swing.JLabel lblVersion;
    // End of variables declaration//GEN-END:variables
}
